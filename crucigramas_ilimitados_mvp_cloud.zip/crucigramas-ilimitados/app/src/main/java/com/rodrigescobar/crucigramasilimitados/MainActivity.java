package com.rodrigescobar.crucigramasilimitados;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import android.widget.EditText;

public class MainActivity extends Activity {
    private final String[] answers = {"SOL", "LUNA", "CASA"};
    private final String[] clues = {"1. Estrella que ilumina el día (3 letras)", "2. Satélite natural de la Tierra (4 letras)", "3. Lugar donde vivimos (4 letras)"};
    private TextView status;
    private Button[] cells = new Button[25];
    private final char[][] solution = {
        {'S','O','L','#','#'},
        {'#','#','U','#','#'},
        {'L','U','N','A','#'},
        {'#','#','A','#','#'},
        {'C','A','S','A','#'}
    };
    private final char[][] board = new char[5][5];

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        for (int r=0;r<5;r++) for(int c=0;c<5;c++) board[r][c] = solution[r][c]=='#' ? '#' : ' ';
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24,24,24,24);
        page.setBackgroundColor(Color.rgb(245,248,252));

        TextView title = new TextView(this);
        title.setText("CRUCIGRAMAS ILIMITADOS");
        title.setTextSize(23); title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(22,61,102)); title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1,-2));

        TextView subtitle = new TextView(this);
        subtitle.setText("¡Entrena tu mente jugando!");
        subtitle.setTextSize(15); subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0,8,0,18);
        page.addView(subtitle);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(5); grid.setRowCount(5);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        for (int r=0;r<5;r++) for(int c=0;c<5;c++) {
            final int rr=r, cc=c, idx=r*5+c;
            Button b = new Button(this);
            cells[idx]=b;
            b.setPadding(0,0,0,0);
            b.setTextSize(16);
            b.setMinWidth(0); b.setMinimumWidth(0);
            b.setMinHeight(0); b.setMinimumHeight(0);
            b.setAllCaps(false);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width=0; lp.height=56; lp.columnSpec=GridLayout.spec(c,1f); lp.setMargins(2,2,2,2);
            if(solution[r][c]=='#') { b.setEnabled(false); b.setBackgroundColor(Color.rgb(30,43,58)); }
            else {
                b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));
                b.setTextColor(Color.rgb(22,61,102));
                b.setOnClickListener(v -> enterLetter(rr,cc));
            }
            grid.addView(b,lp);
        }
        page.addView(grid, new LinearLayout.LayoutParams(-1,-2));

        TextView clueTitle = new TextView(this);
        clueTitle.setText("PISTAS");
        clueTitle.setTextSize(18); clueTitle.setTypeface(null,Typeface.BOLD);
        clueTitle.setTextColor(Color.rgb(22,61,102)); clueTitle.setPadding(0,18,0,6);
        page.addView(clueTitle);
        for(String clue:clues) {
            TextView t = new TextView(this); t.setText("• "+clue); t.setTextSize(15);
            t.setPadding(2,5,2,5); page.addView(t);
        }

        Button check = new Button(this); check.setText("Comprobar respuestas");
        check.setOnClickListener(v -> checkBoard()); page.addView(check);
        Button clear = new Button(this); clear.setText("Nuevo intento");
        clear.setOnClickListener(v -> { for(int r=0;r<5;r++) for(int c=0;c<5;c++) if(solution[r][c]!='#') board[r][c]=' '; refresh(); status.setText("¡Vamos de nuevo!"); });
        page.addView(clear);
        status = new TextView(this); status.setText("Toca una casilla para escribir una letra.");
        status.setTextSize(14); status.setPadding(0,10,0,0); page.addView(status);
        setContentView(page);
        refresh();
    }

    private void enterLetter(int r,int c) {
        EditText input = new EditText(this);
        input.setSingleLine(true); input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        input.setHint("Una letra");
        new AlertDialog.Builder(this).setTitle("Casilla").setView(input)
            .setPositiveButton("Guardar",(d,w)->{
                String s=input.getText().toString().trim().toUpperCase();
                if(!s.isEmpty()) { board[r][c]=s.charAt(0); refresh(); }
            }).setNegativeButton("Cancelar",null).show();
    }
    private void refresh() {
        for(int r=0;r<5;r++) for(int c=0;c<5;c++) if(solution[r][c]!='#') {
            cells[r*5+c].setText(board[r][c]==' ' ? "" : String.valueOf(board[r][c]));
        }
    }
    private void checkBoard() {
        boolean complete=true, correct=true;
        for(int r=0;r<5;r++) for(int c=0;c<5;c++) if(solution[r][c]!='#') {
            if(board[r][c]==' ') complete=false;
            if(board[r][c]!=solution[r][c]) correct=false;
        }
        if(correct) status.setText("¡Excelente! ¡Crucigrama completado!");
        else if(!complete) status.setText("Todavía hay casillas vacías. ¡Sigue intentando!");
        else status.setText("Hay algunas letras incorrectas. ¡Puedes corregirlas!");
        Toast.makeText(this, status.getText(), Toast.LENGTH_SHORT).show();
    }
}
